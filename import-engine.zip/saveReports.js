"use server";

import { supabase } from "../supabase";
import { getOrCreateWorkDay } from "./getOrCreateWorkDay";

function toNumber(value) {
  if (value === null || value === undefined) return 0;

  return (
    Number(
      String(value)
        .replace(/,/g, "")
        .replace(/[^\d.-]/g, "")
    ) || 0
  );
}

export async function saveReports({
  reportDate,
  rows,
}) {
  if (!reportDate) {
    return {
      success: false,
      message: "Report date is missing.",
    };
  }

  if (!rows || rows.length === 0) {
    return {
      success: false,
      message: "No rows to import.",
    };
  }

  //------------------------------------------------
  // Get / Create Work Day
  //------------------------------------------------

  const dayId = await getOrCreateWorkDay(reportDate);

  //------------------------------------------------
  // Build Payload
  //------------------------------------------------

  const payload = rows
    .filter(
      (r) =>
        r.matchedCinema &&
        r.matchedMovie
    )
    .map((r) => ({
      day_id: dayId,

      report_date: reportDate,

      cinema_id: r.cinemaId,

      movie_id: r.movieId,

      tickets: toNumber(
        r.tickets ?? r.audience
      ),

      revenue: toNumber(r.revenue),
    }));

  if (!payload.length) {
    return {
      success: false,
      message: "No matched rows.",
    };
  }

  //------------------------------------------------
  // Remove Old Report
  //------------------------------------------------

  const { error: deleteError } =
    await supabase
      .from("boxoffice_reports")
      .delete()
      .eq("day_id", dayId);

  if (deleteError) {
    throw deleteError;
  }

  //------------------------------------------------
  // Insert New
  //------------------------------------------------

  const { error } = await supabase
    .from("boxoffice_reports")
    .insert(payload);

  if (error) {
    throw error;
  }

  return {
    success: true,
    imported: payload.length,
    dayId,
  };
}