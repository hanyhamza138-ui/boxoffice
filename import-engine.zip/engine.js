import { excelReader } from "./readers/excelReader";
import { csvReader } from "./readers/csvReader";
import { pdfReader } from "./readers/pdfReader";
import { imageReader } from "./readers/imageReader";
import { textReader } from "./readers/textReader";

import { detectTemplate } from "./detectTemplate";
import { parseByTemplate } from "./parseByTemplate";

import { matchCinema } from "./matcher/cinemaMatcher";
import { matchMovie } from "./matcher/movieMatcher";

import { validateRows } from "./validator/validator";

function extension(file) {
  return file.name.split(".").pop().toLowerCase();
}

async function read(file) {
  switch (extension(file)) {
    case "xlsx":
    case "xls":
      return await excelReader(file);

    case "csv":
      return await csvReader(file);

    case "pdf":
      return await pdfReader(file);

    case "png":
    case "jpg":
    case "jpeg":
      return await imageReader(file);

    case "txt":
      return await textReader(file);

    default:
      throw new Error("Unsupported file");
  }
}

export async function importEngine(file) {
  //-----------------------------------
  // Read Document
  //-----------------------------------

  const document = await read(file);

  //-----------------------------------
  // Detect Template
  //-----------------------------------

  const template = detectTemplate(document);

  if (!template) {
    throw new Error(
      "No matching template found."
    );
  }

  //-----------------------------------
  // Parse
  //-----------------------------------

  const parsed = parseByTemplate(
    document,
    template
  );

  //-----------------------------------
  // Validate
  //-----------------------------------

  const cleanRows = validateRows(
    parsed.rows
  );

  //-----------------------------------
  // Match
  //-----------------------------------

  const result = [];

  for (const row of cleanRows) {
    const cinema = await matchCinema(
      row.cinema
    );

    const movie = await matchMovie(
      row.movie
    );

    result.push({
      ...row,

      cinemaId: cinema?.item?.id ?? null,
      cinemaName:
        cinema?.item?.name ??
        row.cinema,
      matchedCinema: !!cinema,

      movieId: movie?.item?.id ?? null,
      movieName:
        movie?.item?.title ??
        row.movie,
      matchedMovie: !!movie,
    });
  }

  return {
    reportDate:
      parsed.reportDate,
    template:
      template.name,
    rows: result,
  };
}