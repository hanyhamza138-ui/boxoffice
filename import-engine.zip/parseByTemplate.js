function clean(value) {
  return String(value ?? "").trim();
}

function normalize(value) {
  return clean(value).toLowerCase();
}

function findHeader(rows, template) {
  const movieName = normalize(template.columns.movie);

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];

    const found = row.some(
      (cell) =>
        normalize(cell) === movieName
    );

    if (found) return i;
  }

  return -1;
}

function findColumn(row, title) {
  title = normalize(title);

  return row.findIndex(
    (c) => normalize(c) === title
  );
}

function isStop(row, template) {
  const text = normalize(row.join(" "));

  return template.stopWords.some((w) =>
    text.includes(normalize(w))
  );
}

function findDate(rows) {
  const regex =
    /\b(20\d{2})[-\/](\d{1,2})[-\/](\d{1,2})\b/;

  for (const row of rows) {
    for (const cell of row) {
      const value = clean(cell);

      const match = value.match(regex);

      if (match) {
        return `${match[1]}-${match[2].padStart(
          2,
          "0"
        )}-${match[3].padStart(2, "0")}`;
      }
    }
  }

  return "";
}

export function parseByTemplate(
  document,
  template
) {
  const sheet = document.sheets[0];

  const rows = sheet.rows || [];

  const reportDate = findDate(rows);

  const headerIndex = findHeader(
    rows,
    template
  );

  if (headerIndex === -1) {
    return {
      reportDate,
      rows: [],
    };
  }

  const header = rows[headerIndex];

  const movieCol = findColumn(
    header,
    template.columns.movie
  );

  const ticketsCol = findColumn(
    header,
    template.columns.tickets
  );

  const revenueCol = findColumn(
    header,
    template.columns.revenue
  );

  const cinema =
    clean(rows[headerIndex - 1]?.[0]);

  const result = [];

  for (
    let i = headerIndex + 1;
    i < rows.length;
    i++
  ) {
    const row = rows[i];

    if (isStop(row, template))
      break;

    const movie = clean(row[movieCol]);

    if (!movie) continue;

    result.push({
      reportDate,
      cinema,
      movie,
      tickets: row[ticketsCol],
      revenue: row[revenueCol],
    });
  }

  return {
    reportDate,
    rows: result,
  };
}